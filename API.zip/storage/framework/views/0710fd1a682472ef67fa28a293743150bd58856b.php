<div class="container">
    <?php $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e(var_dump(json_decode($estate->Photos, true)["Photo"])); ?>

    	<!-- <?php echo e(var_dump(json_decode($estate->Photos)->Photo[0]->MediaURL)); ?> -->
    	<!-- <?php $__currentLoopData = json_decode($estate->Photos, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<?php echo e(var_dump($photo[0]["MediaURL"])); ?>

    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- <?php echo e(json_decode($estate->Photos, true)["Photo"][0]["MediaURL"]); ?> -->
</div>

<?php echo e($estates->links()); ?>


