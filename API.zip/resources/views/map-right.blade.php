<div class="col-md-6">
	<div class="map-column" style="position: fixed; width: 50%; height: 100%;">
		<div id="map" class="map-div col-xs-12"></div>
	</div>
	<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDssDEyM2r6dYD-PQprIdt5Sy6cPJMzPvs&callback=initMap">
	</script>
	<script src="{{asset('js/marker.js')}}"></script>
</div>